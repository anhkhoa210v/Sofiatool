"""Logging màu (rich) + ghi log ra file (xoay vòng — giới hạn kích thước)."""
import logging
import os

from logging.handlers import RotatingFileHandler

from rich.logging import RichHandler

# Mặc định: mỗi file tối đa 10MB, giữ 2 backup (sofia.log + 2 backup ≈ 30MB)
DEFAULT_MAX_BYTES = 10 * 1024 * 1024
DEFAULT_BACKUP_COUNT = 2

_log = None


def get_logger():
    global _log
    if _log is None:
        _log = logging.getLogger("sofia")
        _log.setLevel(logging.DEBUG)
        _log.propagate = False
        handler = RichHandler(rich_tracebacks=True, show_path=False, markup=True)
        handler.setLevel(logging.INFO)
        _log.addHandler(handler)
    return _log


def setup_file_logging(log_path, max_bytes=DEFAULT_MAX_BYTES, backup_count=DEFAULT_BACKUP_COUNT):
    """Ghi log ra file xoay vòng: quá max_bytes → xoay sofia.log.1, .2...

    Giữ tổng dung lượng log bị chặn ≈ max_bytes * (backup_count + 1)
    thay vì tăng trưởng vô hạn khi chạy lâu.
    """
    os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)
    try:
        handler = RotatingFileHandler(
            log_path, maxBytes=max(1024, max_bytes),
            backupCount=max(0, backup_count), encoding="utf-8",
        )
    except (OSError, ValueError):
        # Nơi đọc-ghi không xoay được (FS lạ) → fallback file thường
        handler = logging.FileHandler(log_path, encoding="utf-8")
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    get_logger().addHandler(handler)


def log():
    return get_logger()


def debug(msg):
    log().debug(msg)


def info(msg):
    log().info(msg)


def success(msg):
    log().info(f"[green]{msg}[/green]")


def warn(msg):
    log().warning(msg)


def error(msg):
    log().error(f"[red]{msg}[/red]")

