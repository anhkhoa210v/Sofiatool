"""Wrapper subprocess cho masscan / httpx / nuclei / dig / openssl."""
import shutil
import subprocess

from utils.logger import debug, warn


def which(binary):
    return shutil.which(binary)


def require(binary):
    path = shutil.which(binary)
    if not path:
        raise RuntimeError(f"Thiếu binary bắt buộc: {binary}")
    return path


def run(cmd, timeout=300, input_text=None):
    """Chạy lệnh, capture stdout/stderr; không bao giờ raise ra ngoài."""
    debug(f"[runner] {' '.join(cmd)}")
    try:
        return subprocess.run(
            cmd,
            input=input_text,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except FileNotFoundError:
        warn(f"[runner] không tìm thấy binary: {cmd[0]}")
        return subprocess.CompletedProcess(cmd, 127, "", "not found")
    except subprocess.TimeoutExpired:
        warn(f"[runner] timeout: {' '.join(cmd)}")
        return subprocess.CompletedProcess(cmd, 124, "", "timeout")

