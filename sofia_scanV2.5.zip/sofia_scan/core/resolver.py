"""STAGE 4: PTR (dig -x) + TLS SAN/CN (openssl) → output/t.txt (danh sách domain)."""
import ipaddress
import re
import shutil
from urllib.parse import urlparse

from utils import file_io, runner
from utils.logger import info, warn

CN_RE = re.compile(r"CN\s*=\s*([^\s,/]+)")
DNS_RE = re.compile(r"DNS:([^,\s\n]+)")


def ptr_lookup(ip, timeout=5):
    """PTR qua dig +short -x; fallback socket.gethostbyaddr. Không raise."""
    if shutil.which("dig") is not None:
        proc = runner.run(["dig", "+short", "-x", ip], timeout=timeout + 5)
        for line in (proc.stdout or "").splitlines():
            name = line.strip().rstrip(".")
            if name:
                return name
        return ""
    try:
        return socket_gethostbyaddr(ip)
    except Exception:
        return ""


def socket_gethostbyaddr(ip):
    return __import__("socket").gethostbyaddr(ip)[0].rstrip(".")


def tls_raw(host, port, timeout=10):
    """openssl s_client | x509 -noout -text → text chứng chỉ (hoặc '')."""
    cmd = (
        f"echo | openssl s_client -connect {host}:{port} "
        f"-servername {host} 2>/dev/null | openssl x509 -noout -text"
    )
    proc = runner.run(["bash", "-lc", cmd], timeout=timeout + 10)
    return proc.stdout or ""


def parse_cert_text(text):
    """Trích CN + toàn bộ DNS: trong SAN → set tên thường hóa lowercase."""
    names = set()
    match = CN_RE.search(text)
    if match:
        cn = match.group(1).strip().strip(".").lower()
        if cn:
            names.add(cn)
    for match in DNS_RE.finditer(text):
        name = match.group(1).strip().strip("*.").strip(".").lower()
        if name:
            names.add(name)
    return names


def tls_names(host, port, timeout=10):
    return parse_cert_text(tls_raw(host, port, timeout))


def _is_ip(name):
    try:
        ipaddress.ip_address(name)
        return True
    except ValueError:
        return False


def parse_url(url):
    parsed = urlparse(url)
    return parsed.hostname or "", parsed.port or (443 if parsed.scheme == "https" else 80)


def run(urls, workdir, global_t, cfg):
    """urls: list URL Magento → list domain (PTR + SAN + CN); append vào t.txt."""
    timeout = cfg.get("timeout", 15)
    domains = set()
    for url in urls:
        host, port = parse_url(url)
        if not host:
            continue
        ptr = ptr_lookup(host, timeout)
        if ptr:
            domains.add(ptr.rstrip(".").lower())
        if port == 443:
            for name in tls_names(host, port, timeout):
                if not _is_ip(name):
                    domains.add(name)

    lines = sorted(domains)
    info(f"stage4: {len(lines)} domain (pipeline ghi vào {global_t})")
    if not lines:
        warn("stage4: không thu được domain nào trong dải này")
    return lines


