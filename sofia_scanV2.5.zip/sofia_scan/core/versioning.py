"""STAGE 2b: lấy version Magento → output/magento_versions.txt.

Thứ tự thử (rẻ → đắt, dùng chung session để tận dụng keep-alive):
  1. GET /magento_version      — text "Magento/2.4.6-p3" (nếu cấu hình lỏ)
  2. GET /static/version/      — JSON {"version": "2.4.6-p3"} (Magento 2.4+)
Không có endpoint nào lộ → bỏ qua (không raise).

run() giờ trả về dict url → version để stage 3 khớp CVE offline.
"""
import json
import re

import requests
import urllib3

from utils import file_io
from utils.logger import info

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

USER_AGENT = "Mozilla/5.0 (compatible; SofiaScan/1.0)"

VERSION_RE = re.compile(r"Magento/?\s*v?\s*([0-9][0-9A-Za-z.\-p_]*)", re.IGNORECASE)
JSON_VERSION_KEYS = ("version", "magento_version")


def _from_magento_version(text):
    match = VERSION_RE.search((text or "")[:200])
    if match:
        return f"Magento/{match.group(1)}"
    return None


def _from_static_version(text):
    """Parse JSON /static/version/ → 'Magento/2.4.6-p3' hoặc None."""
    try:
        data = json.loads((text or "")[:2000])
    except (ValueError, TypeError):
        return None
    if not isinstance(data, dict):
        return None
    for key in JSON_VERSION_KEYS:
        value = data.get(key)
        if isinstance(value, str) and value:
            return f"Magento/{value}"
    return None


def fetch_version(url, timeout):
    """Trả về chuỗi kiểu 'Magento/2.4.6-p3' hoặc None. Không bao giờ raise."""
    session = requests.Session()
    session.verify = False
    session.headers["User-Agent"] = USER_AGENT
    base = url.rstrip("/")
    try:
        resp = session.get(base + "/magento_version", timeout=timeout,
                           allow_redirects=True)
        version = _from_magento_version(resp.text)
        if version:
            return version
        resp = session.get(base + "/static/version/", timeout=timeout,
                           allow_redirects=True)
        version = _from_static_version(resp.text)
        if version:
            return version
    except requests.RequestException:
        pass
    return None


def run(urls, workdir, global_versions, cfg):
    """urls: list URL Magento → dict {url: version}; append 'url version' ra file."""
    timeout = cfg.get("timeout", 15)
    versions = {}
    rows = []
    for url in urls:
        version = fetch_version(url, timeout)
        if version:
            versions[url] = version
            rows.append(f"{url} {version}")
    file_io.append_lines(global_versions, rows)
    info(f"stage2b: {len(rows)}/{len(urls)} URL có version")
    return versions
