"""STAGE 2a: phát hiện Magento — probe ĐA ENDPOINT + chấm điểm tin cậy.

Thay vì chỉ GET trang chủ, mỗi host được probe thêm các endpoint đặc trưng
(cấu hình `fingerprint.endpoints`, mặc định):
    /rest/V1/          → REST API (JSON)
    /graphql           → GraphQL API (JSON)
    /static/version/   → static content version (Magento 2)
    /magento_version   → lộ version nếu cấu hình lỏng

Mỗi bằng chứng cộng điểm (confidence scoring):
    header x-magento*/x-mage*            +3
    cookie mage-*/private_content_version/x-magento-vary  +3
    cookie frontend=                      +2
    body chữ ký MẠNH (Magento_*, data-mage-init, ...)     +3
    body chữ ký TRUNG BÌNH (branding)     +2
    >=3 từ "magento" trong body           +1
    /rest/V1/ trả JSON                    +3
    /graphql trả JSON                     +3
    /static/version/ HTTP 200             +2
    /magento_version trả version          +3

Tổng đạt `fingerprint.min_score` (mặc định 3) → kết luận là Magento.
Short-circuit: đạt ngưỡng thì dừng probe sớm (tiết kiệm request).
Có probe được nhiều endpoint → bắt được các site đổi theme/custom asset
nhưng còn REST/GraphQL, nâng tỉ lệ nhận diện so với bản cũ chỉ đọc trang chủ.

Output:
    magento.txt            — 1 URL Magento mỗi dòng (contract cũ, giữ nguyên)
    output/work/<slug>/magento_scored.txt — "url score bằng_chứng" (debug)
Contract giữ nguyên: probe → (url, bool); run → list URL Magento.
"""
import concurrent.futures
import os
import re
import shutil

import requests
import urllib3

from utils import file_io, runner
from utils.logger import info

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

USER_AGENT = "Mozilla/5.0 (compatible; SofiaScan/1.0)"
BODY_LIMIT = 200000  # giới hạn body đọc signature (tránh tốn RAM trên trang lớn)

DEFAULT_ENDPOINTS = ("/rest/V1/", "/graphql", "/static/version/", "/magento_version")
DEFAULT_MIN_SCORE = 3

# --- Headers ----------------------------------------------------------------
HEADER_PREFIXES = ("x-magento", "mage-", "x-mage")

# Tên cookie do Magento đặt (kiểm tra trên Set-Cookie và Cookie)
COOKIE_NAMES = re.compile(
    r"(?:^|[;\s=])(?:mage-[a-z0-9_-]+|private_content_version|x-magento-vary)"
    r"[\s;=]", re.I,
)
FRONTEND_COOKIE = re.compile(r"frontend=", re.I)

# --- Body: chữ ký MẠNH (đặc trưng riêng của Magento) -------------------------
STRONG_BODY = (
    # Magento 2: widget/component JS — "Magento_Theme/js/view/...", Magento_Ui
    re.compile(r"Magento_[A-Za-z0-9_]+"),
    # Magento 2: data-mage-init / x-magento-init (requirejs bootstrap inline)
    re.compile(r"data-mage-init"),
    re.compile(r"x-magento-init"),
    # Magento 2: lib web mage — /lib/web/mage/requirejs/..., mage/cookies.js
    re.compile(r"/lib/web/mage/"),
    # Magento 2: theme path — frontend/Magento/luma, frontend/Magento/blank
    re.compile(r"frontend/Magento/(?:luma|blank)\b"),
    # Magento 2: requirejs config / mage/* script paths
    re.compile(r"mage/(?:requirejs|cookies|url|translate|validation|apply)"),
    re.compile(r"requirejs-magento"),
    # Magento 2: static versioned assets — /static/version1699999999/frontend/...
    re.compile(r"static/version\d{6,}/"),
    re.compile(r"pub/static/"),
    # Magento 2: REST API path trong HTML
    re.compile(r"/rest/V[12]/"),
    # Magento 1 & 2
    re.compile(r"skin/frontend/"),
    # Magento 1: varien JS library, VarienForm
    re.compile(r"varien/[a-z0-9_]+", re.I),
    re.compile(r"VarienForm"),
    # Magento 1: Mage object / Mage.Cookies, Mage.cache, Mage.app, Mage.baseURL
    re.compile(r"Mage\.(?:Cookies|cache|app|baseURL)\b"),
    # Magento 1 Connect downloader
    re.compile(r"/downloader/\?url="),
    # <meta name="generator" content="Magento ...">
    re.compile(r"<meta[^>]+name=[\"']generator[\"'][^>]+content=[\"'][^>]*magento", re.I),
    re.compile(r"<meta[^>]+content=[\"'][^>]*magento[^>]*name=[\"']generator[\"']", re.I),
    # HTML attribute trỏ tới path/asset Magento
    re.compile(r"""(?:href|src)\s*=\s*["'][^"']*magento""", re.I),
)

# --- Body: chữ ký TRUNG BÌNH (tên thương mại — 1 hit là xác nhận) -----------
MEDIUM_BODY = (
    re.compile(r"powered\s+by\s+magento", re.I),
    re.compile(r"Magento\s+Commerce", re.I),
    re.compile(r"Adobe\s+Commerce", re.I),
)

# --- Body: chữ ký YẾU (từ "magento" thường trong text) -----------------------
WEAK_WORD = re.compile(r"\bmagento\b", re.I)
WEAK_MIN_OCCURRENCES = 3

# --- /magento_version --------------------------------------------------------
VERSION_RE = re.compile(
    r"^\s*(Magento/\d+\.\d+(?:\.\d+)?(?:-p\d+)?(?:\s*\([^)]*\))?)", re.I,
)
HTML_TYPES = re.compile(r"text/html", re.I)
JSON_TYPES = re.compile(r"application/json", re.I)


def _hdrs(headers):
    return {str(k).lower(): str(v) for k, v in (headers or {}).items()}


def score_response(status, headers, body, endpoint=None):
    """Chấm điểm 1 response HTTP. Trả về (score, [bằng_chứng]).

    Bằng chứng dạng "header:x-magento-*", "cookie:mage", "body:strong", ...
    """
    hdrs = _hdrs(headers)
    score = 0
    evidence = []

    for header, value in hdrs.items():
        if header.startswith(HEADER_PREFIXES):
            score += 3
            evidence.append(f"header:{header}")
            break
    for header, value in hdrs.items():
        if header in ("set-cookie", "cookie"):
            if COOKIE_NAMES.search(value):
                score += 3
                evidence.append("cookie:mage")
            elif FRONTEND_COOKIE.search(value):
                score += 2
                evidence.append("cookie:frontend")

    body = body or ""
    if any(p.search(body) for p in STRONG_BODY):
        score += 3
        evidence.append("body:strong")
    if any(p.search(body) for p in MEDIUM_BODY):
        score += 2
        evidence.append("body:medium")
    hits = len(WEAK_WORD.findall(body))
    if hits >= WEAK_MIN_OCCURRENCES:
        score += 1
        evidence.append(f"body:weak x{hits}")

    if endpoint:
        if endpoint == "/magento_version":
            ok, _version = check_magento_version_response(status, headers, body)
            if ok:
                score += 3
                evidence.append("endpoint:magento_version")
        elif endpoint.startswith("/rest/"):
            if status == 200 and JSON_TYPES.search(hdrs.get("content-type", "")):
                score += 3
                evidence.append("endpoint:rest")
        elif endpoint == "/graphql":
            if status == 200 and JSON_TYPES.search(hdrs.get("content-type", "")):
                score += 3
                evidence.append("endpoint:graphql")
        elif endpoint == "/static/version/":
            if status == 200:
                score += 2
                evidence.append("endpoint:static_version")

    return score, evidence


def check_magento(status, headers, body, min_score=DEFAULT_MIN_SCORE):
    """Signature check (contract cũ): True nếu response đạt ngưỡng điểm."""
    score, _evidence = score_response(status, headers, body)
    return score >= min_score


def check_magento_version_response(status, headers, body):
    """Response của GET /magento_version.

    Chặt hơn: yêu cầu HTTP 200 + content-type KHÔNG phải text/html (tránh
    catch-all rewrite trả về trang HTML chứa text "Magento/2.x").
    Trả về (bool, version) — version rò rỉ để log.
    """
    if status != 200:
        return False, None
    ctype = _hdrs(headers).get("content-type", "")
    if HTML_TYPES.search(ctype):
        return False, None
    body = (body or "")[:200].strip()
    match = VERSION_RE.match(body)
    if not match:
        return False, None
    return True, match.group(1)


def _endpoints_from_cfg(cfg):
    """Đọc fingerprint.endpoints; fallback legacy probe_magento_version."""
    fp = cfg.get("fingerprint") or {}
    endpoints = fp.get("endpoints")
    if endpoints:
        return tuple(endpoints)
    # Legacy: chỉ probe /magento_version nếu bật (bản cũ)
    if cfg.get("probe_magento_version", True):
        return ("/magento_version",)
    return ()


def _min_score_from_cfg(cfg):
    fp = cfg.get("fingerprint") or {}
    return int(fp.get("min_score", DEFAULT_MIN_SCORE))


def _probe(url, timeout, endpoints, min_score):
    """Probe chi tiết → (url, is_magento, score, evidence). Không bao giờ raise."""
    session = requests.Session()
    session.verify = False
    session.headers["User-Agent"] = USER_AGENT

    total = 0
    evidence = []

    def visit(path):
        nonlocal total, evidence
        resp = session.get(path, timeout=timeout, allow_redirects=True)
        score, ev = score_response(
            resp.status_code, dict(resp.headers), resp.text[:BODY_LIMIT],
            endpoint=None if path == url else path[len(url):],
        )
        total += score
        evidence.extend(ev)

    try:
        visit(url)
        if total >= min_score:
            return url, True, total, evidence
        for ep in endpoints:
            try:
                visit(url + ep)
            except requests.RequestException:
                continue
            if total >= min_score:
                return url, True, total, evidence
        return url, total >= min_score, total, evidence
    except requests.RequestException:
        return url, False, total, evidence


def probe(url, timeout, endpoints=DEFAULT_ENDPOINTS, min_score=DEFAULT_MIN_SCORE):
    """Contract cũ: GET các endpoint; trả về (url, is_magento)."""
    return _probe(url, timeout, endpoints, min_score)[:2]


def _scheme_for(host_port):
    return "https" if host_port.endswith(":443") else "http"


def httpx_detect(live_file, timeout):
    """Dùng httpx -tech-detect nếu binary có sẵn; trả về set URL có Magento."""
    if shutil.which("httpx") is None:
        return set()
    proc = runner.run(
        ["httpx", "-l", live_file, "-tech-detect", "-status-code", "-silent",
         "-no-color", "-timeout", str(timeout)],
        timeout=max(600, timeout * 60),
    )
    out = set()
    for line in (proc.stdout or "").splitlines():
        if "magento" in line.lower():
            out.add(line.split()[0].strip())
    return out


def run(hosts, workdir, global_magento, cfg):
    """hosts: list 'ip:port' → list URL Magento; append vào global_magento."""
    timeout = cfg.get("timeout", 15)
    endpoints = _endpoints_from_cfg(cfg)
    min_score = _min_score_from_cfg(cfg)
    urls = [f"{_scheme_for(h)}://{h}" for h in hosts]

    found = set()
    scored = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=cfg.get("threads", 50)) as pool:
        futures = [
            pool.submit(_probe, u, timeout, endpoints, min_score) for u in urls
        ]
        for future in concurrent.futures.as_completed(futures):
            url, is_magento, score, evidence = future.result()
            scored.append(f"{url} {score} {' '.join(evidence)}".strip())
            if is_magento:
                found.add(url)

    if hosts:
        live_file = os.path.join(workdir, "live.txt")
        file_io.write_lines(live_file, hosts)
        found |= {u for u in httpx_detect(live_file, timeout) if u in set(urls)}

    found = file_io.dedupe_sort(found)
    file_io.append_lines(global_magento, found)

    scored_file = os.path.join(workdir, "magento_scored.txt")
    file_io.write_lines(scored_file, file_io.dedupe_sort(scored))
    info(f"stage2a: {len(found)}/{len(urls)} URL là Magento "
         f"(min_score={min_score}, endpoints={','.join(endpoints) or '-'})")
    return found

