#!/usr/bin/env python3
"""Upload định kỳ output/t.txt (danh sách domain cửa hàng thật) lên GoFile
→ gửi link về webhook.

NÂNG CẤP — CHỈ upload khi ĐỦ 2 ĐIỀU KIỆN:
  1. SỐ DOMAIN thay đổi so với lần upload thành công gần nhất
     (so theo SỐ LƯỢNG dòng — thêm/bớt domain nhưng cùng số lượng → không upload).
  2. ĐÃ ĐỦ thời gian tối thiểu `interval` (mặc định 900s = 15 phút)
     kể từ lần upload thành công gần nhất.

Trạng thái (số domain + mốc thời gian) lưu vào <output_dir>/upload_state.json —
khởi động lại daemon không gây upload vội (vẫn tôn trọng 2 điều kiện).

Hai cách dùng:
  1. Tích hợp trong main.py (khuyến nghị):
       import upload_live
       upload_live.start_daemon(cfg)   # background thread, kiểm tra mỗi poll_interval giây
     Webhook lấy từ cfg['webhook'] (config.yaml, ghi đè bằng env SOFIA_WEBHOOK_URL).

  2. Chạy riêng: python3 upload_live.py [--once] [--file ...] [--interval ...]
                 [--poll-interval ...] [--no-count-changed]
     Webhook đọc trực tiếp từ config/config.yaml.
"""
import argparse
import json
import os
import sys
import threading
import time

import requests
import yaml

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from utils import file_io
from utils.logger import error, info, success, warn

INTERVAL_DEFAULT = 15 * 60   # điều kiện 2: thời gian TỐI THIỂU giữa 2 lần upload (giây)
POLL_DEFAULT = 60            # tần suất kiểm tra t.txt (giây)
STATE_FILENAME = "upload_state.json"
T_DEFAULT = os.path.join(BASE_DIR, "output", "t.txt")
CONFIG_PATH = os.path.join(BASE_DIR, "config", "config.yaml")


def load_webhook_config():
    """Trả về (url, type) — ưu tiên env SOFIA_WEBHOOK_URL > config.yaml."""
    url, kind = "", "generic"
    try:
        with open(CONFIG_PATH, encoding="utf-8") as fh:
            wh = (yaml.safe_load(fh) or {}).get("webhook") or {}
        kind = wh.get("type", "generic")
        url = wh.get("url") or ""
    except OSError:
        pass
    url = os.environ.get("SOFIA_WEBHOOK_URL") or url
    return url, kind


def gofile_servers():
    r = requests.get("https://api.gofile.io/servers", timeout=30)
    r.raise_for_status()
    data = (r.json() or {}).get("data") or {}
    servers = data.get("servers") or ([{"name": data["server"]}] if data.get("server") else [])
    return [s["name"] if isinstance(s, dict) else str(s) for s in servers]


def gofile_upload(path):
    """Upload anonymous lên GoFile, trả về link downloadPage. Thử lần lượt các server."""
    last_err = None
    for name in gofile_servers():
        try:
            with open(path, "rb") as fh:
                r = requests.post(
                    f"https://{name}.gofile.io/contents/uploadfile",
                    files={"file": fh},
                    timeout=600,
                )
            r.raise_for_status()
            body = r.json() or {}
            if body.get("status") == "ok":
                page = (body.get("data") or {}).get("downloadPage")
                if page:
                    return page
            last_err = RuntimeError(f"GoFile/{name}: phản hồi {body}")
        except requests.RequestException as exc:
            last_err = exc
    raise last_err or RuntimeError("GoFile: không có server khả dụng")


def send_webhook(url, kind, text):
    if kind == "discord":
        payload = {"content": text[:2000], "username": "SofiaScan"}
    else:  # slack | generic
        payload = {"text": text[:39000]}
    r = requests.post(url, json=payload, timeout=15)
    if r.status_code == 429:  # tôn trọng Retry-After (giống webhook.py)
        wait = min(float(r.headers.get("Retry-After", 5) or 5), 60)
        warn(f"webhook 429 — chờ {wait}s rồi thử lại")
        time.sleep(wait)
        r = requests.post(url, json=payload, timeout=15)
    r.raise_for_status()


def human_size(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:,.0f} {unit}" if unit == "B" else f"{n:,.1f} {unit}"
        n /= 1024.0


# ─────────────────────────── Trạng thái (state) ──────────────────────

def _load_state(path):
    """Đọc trạng thái {last_count, last_upload_ts} — {} nếu chưa có / lỗi."""
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return {}
    out = {}
    if isinstance(data.get("last_count"), int):
        out["last_count"] = data["last_count"]
    if isinstance(data.get("last_upload_ts"), (int, float)):
        out["last_upload_ts"] = data["last_upload_ts"]
    return out


def _save_state(path, state):
    try:
        file_io.atomic_write(path, json.dumps(state, ensure_ascii=False, indent=2) + "\n")
    except OSError as exc:
        warn(f"upload_live: không ghi được state {path}: {exc}")


# ─────────────────────────── Logic upload ────────────────────────────

def _read_count(path):
    """Số domain = số dòng KHÔNG RỖNG trong t.txt. None nếu file thiếu/rỗng."""
    try:
        if not os.path.exists(path) or os.path.getsize(path) == 0:
            return None
        with open(path, encoding="utf-8", errors="ignore") as fh:
            return sum(1 for ln in fh if ln.strip())
    except OSError:
        return None


def _dedupe_stable(path):
    """Loại dòng trùng trong t.txt (giữ thứ tự).

    t.txt được pipeline append theo từng CIDR — chạy lại (--no-resume) sinh
    dòng trùng; dọn trước khi upload để file trên GoFile luôn sạch.
    Trả về True nếu đã ghi lại file.
    """
    try:
        with open(path, encoding="utf-8", errors="ignore") as fh:
            lines = [ln.rstrip("\n") for ln in fh]
    except OSError:
        return False
    seen, out = set(), []
    for line in lines:
        if line and line not in seen:
            seen.add(line)
            out.append(line)
    if len(out) == len(lines):
        return False
    try:
        file_io.atomic_write(path, "".join(o + "\n" for o in out))
        return True
    except OSError:
        return False


def _check_and_upload(file_path, url, kind, state, min_interval, count_changed):
    """Kiểm tra ĐỦ 2 ĐIỀU KIỆN rồi upload.

    Điều kiện 1 — SỐ DOMAIN thay đổi: số dòng hiện tại != số dòng ở lần upload
    thành công gần nhất. Lần đầu tiên (chưa có state) luôn coi là "đã đổi".
    Điều kiện 2 — ĐỦ THỜI GIAN: ≥ min_interval giây kể từ lần upload thành
    công gần nhất. Lần đầu tiên luôn coi là "đủ".

    Trả về (outcome, state_mới); outcome ∈ {'uploaded','skip_missing',
    'skip_count','skip_time'}. Raise nếu upload THỰC SỰ lỗi để worker báo
    webhook và thử lại chu kỳ sau.
    """
    now = time.time()
    count = _read_count(file_path)
    if count is None:
        info(f"upload_live: chưa có/rỗng {os.path.basename(file_path)} — bỏ lượt này")
        return "skip_missing", state
    if _dedupe_stable(file_path):
        info("upload_live: đã loại dòng trùng trong t.txt")
        count = _read_count(file_path) or 0

    last_count = state.get("last_count")
    last_ts = state.get("last_upload_ts")

    # Điều kiện 1 — số domain thay đổi
    if count_changed and last_count is not None and count == last_count:
        info(f"upload_live: số domain không đổi ({count:,}) — chờ thay đổi (điều kiện 1)")
        return "skip_count", state
    # Điều kiện 2 — đủ thời gian tối thiểu
    if last_ts is not None and now - last_ts < min_interval:
        remain = int(min_interval - (now - last_ts))
        info(f"upload_live: chưa đủ {min_interval}s kể từ lần upload trước "
             f"(còn ~{remain}s) — chờ (điều kiện 2)")
        return "skip_time", state

    # Đủ 2 điều kiện → upload + gửi link webhook
    size = os.path.getsize(file_path)
    link = gofile_upload(file_path)
    uploaded_at = time.time()
    success(f"upload_live: đã upload {os.path.basename(file_path)} → {link}")

    if url:
        text = (f"📁 SofiaScan — t.txt (domain cửa hàng thật)\n"
                f"• {count:,} domain, {human_size(size)}\n"
                f"• Tải: {link}")
        try:
            send_webhook(url, kind, text)
            success("upload_live: đã gửi link về webhook")
        except Exception as exc:
            error(f"upload_live: gửi webhook lỗi: {exc}")
    else:
        warn("upload_live: chưa cấu hình webhook — xem link ở log")

    return "uploaded", {"last_count": count, "last_upload_ts": uploaded_at}


# ─────────────────────────── Daemon cho main.py ──────────────────────

def _worker(file_path, url, kind, state_path, min_interval, count_changed, poll_interval):
    state = _load_state(state_path)
    if state.get("last_count") is not None and state.get("last_upload_ts") is not None:
        last_at = time.strftime("%d/%m %H:%M:%S", time.localtime(state["last_upload_ts"]))
        info(f"upload_live: khôi phục state — {state['last_count']:,} domain, "
             f"upload gần nhất lúc {last_at}")
    state_ok = True  # chống spam: chỉ báo lỗi qua webhook khi chuyển OK → lỗi
    while True:
        try:
            outcome, state = _check_and_upload(
                file_path, url, kind, state, min_interval, count_changed)
            if outcome == "uploaded":
                _save_state(state_path, state)
            state_ok = True
        except Exception as exc:
            error(f"upload_live: {exc}")
            if state_ok:
                try:
                    send_webhook(url, kind,
                                 "⚠️ SofiaScan — upload t.txt lên GoFile THẤT BẠI "
                                 "(sẽ thử lại chu kỳ sau)")
                except Exception:
                    pass
            state_ok = False
        time.sleep(poll_interval)


def start_daemon(cfg):
    """Khởi động background thread upload t.txt (tích hợp main.py).

    CHỈ upload khi ĐỦ 2 ĐIỀU KIỆN:
      1. số domain trong t.txt thay đổi so với lần upload thành công gần nhất;
      2. đã đủ cfg['upload']['interval'] giây kể từ lần upload thành công gần nhất.

    cfg: dict config đã merge (DEFAULT_CONFIG + config.yaml):
      - cfg['webhook']['url'] / ['type']  — SOFIA_WEBHOOK_URL ghi đè
      - cfg['paths']['output_dir']        — nơi chứa t.txt + upload_state.json
      - cfg['upload']['enabled'/'interval'/'poll_interval'/'count_changed']
        (legacy 'only_changed' — so hash — được chuyển thành count_changed)
    Trả về Thread (daemon) hoặc None nếu bị tắt / thiếu webhook.
    """
    upload_cfg = cfg.get("upload") or {}
    if not upload_cfg.get("enabled", True):
        info("upload_live: bị tắt (upload.enabled=false)")
        return None

    wh = cfg.get("webhook") or {}
    url = os.environ.get("SOFIA_WEBHOOK_URL") or wh.get("url") or ""
    kind = wh.get("type", "generic")
    if not url:
        warn("upload_live: chưa có webhook.url trong config — không khởi động uploader")
        return None

    min_interval = max(60, int(upload_cfg.get("interval", INTERVAL_DEFAULT)))
    poll_interval = max(10, int(upload_cfg.get("poll_interval", POLL_DEFAULT)))
    count_changed = upload_cfg.get("count_changed", True)
    if "count_changed" not in upload_cfg and "only_changed" in upload_cfg:
        count_changed = bool(upload_cfg["only_changed"])  # legacy → count
    count_changed = bool(count_changed)
    file_path = os.path.join(cfg["paths"]["output_dir"], "t.txt")
    state_path = os.path.join(cfg["paths"]["output_dir"], STATE_FILENAME)

    t = threading.Thread(
        target=_worker, name="upload-live", daemon=True,
        args=(file_path, url, kind, state_path, min_interval, count_changed, poll_interval),
    )
    t.start()
    info(f"upload_live: daemon khởi động — file={file_path}, "
         f"tối thiểu {min_interval}s/upload, kiểm tra mỗi {poll_interval}s, "
         f"chỉ upload khi số domain đổi={count_changed}, webhook type={kind}")
    return t


# ─────────────────────────── Chạy độc lập (CLI) ──────────────────────

def parse_args():
    ap = argparse.ArgumentParser(
        description="Upload t.txt (domain cửa hàng thật) lên GoFile — CHỈ khi ĐỦ 2 điều kiện: "
                    "số domain thay đổi + đã đủ thời gian tối thiểu")
    ap.add_argument("--file", default=T_DEFAULT,
                    help="đường dẫn file upload (mặc định output/t.txt)")
    ap.add_argument("--interval", type=int, default=INTERVAL_DEFAULT,
                    help="điều kiện 2 — thời gian TỐI THIỂU (giây) giữa 2 lần upload "
                         "(mặc định 900 = 15 phút)")
    ap.add_argument("--poll-interval", type=int, default=POLL_DEFAULT,
                    help="tần suất kiểm tra t.txt (giây, mặc định 60)")
    ap.add_argument("--count-changed", action=argparse.BooleanOptionalAction, default=True,
                    help="điều kiện 1 — chỉ upload khi SỐ domain thay đổi (mặc định bật; "
                         "--no-count-changed = upload theo chu kỳ như bản cũ)")
    ap.add_argument("--webhook-url", default="", help="ghi đè URL webhook")
    ap.add_argument("--once", action="store_true",
                    help="chạy 1 lần rồi thoát (vẫn kiểm tra 2 điều kiện)")
    return ap.parse_args()


def main():
    args = parse_args()
    url = args.webhook_url
    kind = "generic"
    if not url:
        url, kind = load_webhook_config()
    state_path = os.path.join(os.path.dirname(args.file) or ".", STATE_FILENAME)
    info(f"upload_live: file={args.file} tối thiểu={args.interval}s "
         f"kiểm tra={args.poll_interval}s count_changed={args.count_changed} "
         f"webhook={'bật' if url else 'tắt'} type={kind}")

    state = _load_state(state_path)
    while True:
        try:
            outcome, state = _check_and_upload(
                args.file, url, kind, state, args.interval, args.count_changed)
            if outcome == "uploaded":
                _save_state(state_path, state)
        except KeyboardInterrupt:
            raise
        except Exception as exc:
            error(f"upload_live: {exc}")
        if args.once:
            return 0
        time.sleep(args.poll_interval)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        error("upload_live: dừng bởi người dùng (Ctrl+C)")
        sys.exit(130)
