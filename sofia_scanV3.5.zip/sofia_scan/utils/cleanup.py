"""Dọn output tự động — xoá/truncate file khi quá nặng (log + live.txt).

NÂNG CẤP — 2 cơ chế bổ sung vào Sofia Scan (block `cleanup` trong config):
  1. LOG: tổng dung lượng sofia.log + các backup (.1, .2...) vượt
     `cleanup.log_total_mb` (MB) → xoá backup CŨ NHẤT tới khi đủ, file chính
     vẫn quá → truncate. Chạy 1 lần ở startup (main.py) và liên tục qua
     CappedRotatingFileHandler (utils/logger.py) mỗi lần xoay vòng.
  2. LIVE.TXT: output/live.txt vượt `cleanup.live_txt_max_mb` (MB) → cắt bớt,
     GIỮ `cleanup.live_txt_keep_lines` dòng CUỐI (dòng mới nhất — kết quả gần
     đây của pipeline). Đọc ngược theo block nên không load cả file vào RAM
     (live.txt có thể hàng trăm MB). Chạy ở startup + sau mỗi CIDR trong
     pipeline (chỉ tốn 1 lần get size mỗi CIDR).

Giá trị 0 / tắt `enabled=false` → không dọn (chạy như bản cũ).
"""
import glob
import os

from utils import file_io
from utils.logger import info

_MB = 1024 * 1024
DEFAULT_LIVE_KEEP_LINES = 500_000   # dòng cuối giữ lại khi cắt live.txt
_TAIL_BLOCK = 1 << 16               # đọc ngược từng 64KB — không load cả file


def load(cfg):
    """Chuẩn hóa block `cleanup` của config → dict an toàn."""
    cl = cfg.get("cleanup") or {}
    return {
        "enabled": bool(cl.get("enabled", True)),
        "log_total_mb": float(cl.get("log_total_mb") or 0),
        "live_txt_max_mb": float(cl.get("live_txt_max_mb") or 0),
        "live_txt_keep_lines": max(1, int(cl.get("live_txt_keep_lines")
                                          or DEFAULT_LIVE_KEEP_LINES)),
    }


def human_mb(n):
    return f"{n / _MB:,.1f} MB"


# ─────────────────────────── LOG ─────────────────────────────────────

def _log_backup_size(log_path):
    """Tổng dung lượng sofia.log + các backup liên quan (.1, .2...)."""
    total = 0
    for name in glob.glob(log_path + "*"):
        try:
            total += os.path.getsize(name)
        except OSError:
            pass
    return total


def enforce_log(log_path, log_total_mb=0, cfg=None):
    """Xoá/truncate log khi TỔNG (chính + backup) vượt trần; trả True nếu đã dọn.

    - Backups > cap bị xoá từ file cũ nhất (mtime cũ — số hậu tố lớn) tới khi
      tổng ≤ cap (handler xoay vòng của RotatingFileHandler chỉ giới hạn SỐ
      backup, không giới hạn TỔNG dung lượng).
    - File chính vẫn quá cap → truncate (mất log cũ nhất).
    - log_total_mb <= 0 → tắt. Khi `cfg` truyền vào, ưu tiên đọc từ cfg.
    """
    if cfg is not None:
        log_total_mb = log_total_mb or (load(cfg).get("log_total_mb") or 0)
    cap = int(log_total_mb * _MB)
    if cap <= 0 or not os.path.exists(log_path):
        return False

    base_abs = os.path.abspath(log_path)
    backups = sorted(
        (name for name in glob.glob(log_path + ".*")
         if os.path.abspath(name) != base_abs),
        key=lambda p: (os.path.getmtime(p), p),
    )
    total = _log_backup_size(log_path)
    removed = 0
    while backups and total > cap:
        oldest = backups.pop(0)
        try:
            total -= os.path.getsize(oldest)
            os.remove(oldest)
            removed += 1
        except OSError:
            break
    if total > cap:
        try:
            with open(log_path, "w", encoding="utf-8"):
                pass
            removed += 1
        except OSError:
            pass
    if removed:
        info(f"cleanup: tổng log vượt trần {log_total_mb:,.0f}MB — "
             f"đã dọn {removed} file (còn {human_mb(total)})")
    return removed > 0


# ─────────────────────────── LIVE.TXT ────────────────────────────────

def _tail_lines(path, n):
    """`n` dòng CUỐI của file (đọc ngược theo block — không load cả file)."""
    size = os.path.getsize(path)
    if size <= 0:
        return []
    buf = b""
    pos = size
    with open(path, "rb") as fh:
        while pos > 0 and buf.count(b"\n") < n:
            read = min(_TAIL_BLOCK, pos)
            pos -= read
            fh.seek(pos)
            buf = fh.read(read) + buf
    lines = buf.decode("utf-8", errors="ignore").splitlines()
    return lines[-n:] if len(lines) > n else lines


def truncate_live(path, keep_lines=DEFAULT_LIVE_KEEP_LINES):
    """Cắt live.txt: chỉ giữ `keep_lines` dòng mới nhất (ghi đè nguyên tử).

    Trả list dòng giữ lại (để caller đếm) — empty nếu file rỗng.
    """
    lines = _tail_lines(path, keep_lines) if os.path.exists(path) else []
    file_io.write_lines(path, lines)
    return lines


def enforce_live(live_path, cfg=None, max_mb=0,
                 keep_lines=DEFAULT_LIVE_KEEP_LINES):
    """Trả True nếu live.txt vượt `max_mb` (MB) và đã bị cắt bớt.

    live_txt_max_mb <= 0 → tắt. Khi `cfg` truyền vào, ưu tiên đọc từ block
    `cleanup` của cfg.
    """
    if cfg is not None:
        cl = load(cfg)
        if not cl["enabled"]:
            return False
        max_mb = max_mb or cl["live_txt_max_mb"]
        keep_lines = cl["live_txt_keep_lines"]
    cap = int(max_mb * _MB)
    if cap <= 0 or not os.path.exists(live_path):
        return False
    before = os.path.getsize(live_path)
    if before <= cap:
        return False
    lines = truncate_live(live_path, keep_lines)
    after = os.path.getsize(live_path)
    info(f"cleanup: live.txt {human_mb(before)} → vượt {max_mb:,.0f}MB, "
         f"giữ {len(lines):,} dòng cuối ({human_mb(after)})")
    return True
