"""STAGE 3: phát hiện CVE Magento — 2 lớp độc lập:

  A. OFFLINE (version match) — luôn chạy, không cần nuclei:
     version từ stage 2b → khớp cves/version_map.yaml (core/cve_map.py) →
     dòng "[version] url ver — khả năng CVE-... [severity] name (khoảng dính)".
     Không gửi request thêm; nếu URL không có version thì không có dòng này.

  B. ONLINE (nuclei) — CÓ THỂ TẮT qua cve.nuclei.enabled:
     1) template local trong cves/<CVE>.yaml qua -t; id trong template PHẢI
        khớp tên file (chống gán nhầm CVE cho kết quả) — lệch là bỏ qua;
     2) template cộng đồng qua -id (cve.community_ids).
     Một CVE vừa có template local vừa có trong community_ids → CHỈ chạy
     bản local (tránh quét trùng 2 lần cùng 1 CVE).

Cờ điều khiển mức độ ăn to (chống block/đỡ tốn băng thông) ở cve.nuclei:
  concurrency (-c), rate_limit (-rl), timeout (-timeout), retries (-retries),
  follow_redirects (trước đây code cứng "-fr" — thực chất là follow-redirects,
  KHÔNG phải "giảm false positive" như chú thích cũ), max_seconds (chặn mềm
  mỗi lượt nuclei), local_templates / community (bật tắt từng nguồn),
  severity (chỉ giữ finding mức này trở lên; rỗng = tất cả).

Kết quả A + B gộp append vào output/vuln.txt; riêng A còn ghi
output/work/<slug>/cve_version.txt. Hàm nào cũng không raise (an toàn pipeline).
"""
import os
import re
import shutil
from urllib.parse import urlparse

import yaml

from core import cve_map
from utils import file_io, runner
from utils.logger import info, warn

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CVE_DIR = os.path.join(BASE_DIR, "cves")

# Trích URL từ dòng finding (version match + nuclei đều bắt đầu bằng URL)
# Escaped `\"` — chuỗ ra là raw string, backslash giữ → class chỉ literal `\"`
URL_RE = re.compile(r"""https?://[^\s]+[^\s.,;:)\]}'"]""", re.IGNORECASE)

DEFAULT_NUCLEI_MAX_SECONDS = 7200

# Cache nhận diện flag của nuclei (đọc -help 1 lần) — chống lệch version:
# chỉ truyền cờ chắc chắn nuclei bản đang chạy hỗ trợ.
_FLAG_CACHE = {"help": None}


def _nuclei_help():
    """toàn bộ -help của nuclei (cache) hoặc '' nếu đọc thất bại."""
    if _FLAG_CACHE["help"] is None:
        try:
            proc = runner.run(["nuclei", "-help"], timeout=60)
            _FLAG_CACHE["help"] = (proc.stdout or "") + "\n" + (proc.stderr or "")
        except Exception:
            _FLAG_CACHE["help"] = ""
    return _FLAG_CACHE["help"]


def _nuclei_supports(*tokens):
    """True nếu nuclei -help có chứa bất kỳ token nào (vd "-follow-redirects")."""
    help_text = _nuclei_help()
    return any(re.search(re.escape(token), help_text, re.I) for token in tokens)


def nuclei_config(cfg):
    """Chuẩn hóa block cve.nuclei — điền default, trả dict an toàn."""
    nuc = (cfg.get("cve") or {}).get("nuclei") or {}
    return {
        "enabled": bool(nuc.get("enabled", True)),
        "concurrency": int(nuc.get("concurrency") or 0),
        "rate_limit": int(nuc.get("rate_limit") or 0),
        "timeout": int(nuc.get("timeout") or cfg.get("timeout") or 15),
        "retries": int(nuc.get("retries") or 2),
        "follow_redirects": bool(nuc.get("follow_redirects", False)),
        "max_seconds": int(nuc.get("max_seconds") or DEFAULT_NUCLEI_MAX_SECONDS),
        "local_templates": bool(nuc.get("local_templates", True)),
        "community": bool(nuc.get("community", True)),
        "severity": str(nuc.get("severity") or "").strip(),
    }


def _local_template_paths(cfg):
    """Đường dẫn template local cho CVE khai trong cves: (chỉ file tồn tại)."""
    out = []
    for cve in cfg.get("cves") or []:
        path = os.path.join(CVE_DIR, f"{cve}.yaml")
        if os.path.exists(path):
            out.append(path)
        else:
            warn(f"[nuclei] không tìm thấy template local {cve} → {path} (bỏ qua)")
    return out


def _template_cve_id(path):
    """id trong template local (đã normalize hoa) hoặc None nếu không đọc được.

    Chỉ chấp nhận id là CVE-ID hợp lệ — template thiếu id / id lạ bị coi là
    không thể gán kết quả → cảnh báo và loại (tránh dòng tìm thấy bị gắn
    nhầm CVE)."""
    try:
        with open(path, encoding="utf-8") as fh:
            data = yaml.safe_load(fh)
    except (yaml.YAMLError, OSError) as exc:
        warn(f"[nuclei] template {os.path.basename(path)} không đọc được: "
             f"{exc} — bỏ qua (không gán được CVE)")
        return None
    if not isinstance(data, dict):
        warn(f"[nuclei] template {os.path.basename(path)} không phải mapping — bỏ qua")
        return None
    template_id = str(data.get("id") or "").strip().upper()
    if not cve_map._valid_cve(template_id):
        warn(f"[nuclei] template {os.path.basename(path)} id={template_id!r} "
             f"không phải CVE-ID — bỏ qua (chống gán nhầm kết quả)")
        return None
    return template_id


def local_templates(cfg):
    """Template local hợp lệ → [(path, CVE-ID chuẩn)]. Kiểm tra id trùng tên file."""
    valid = []
    for path in _local_template_paths(cfg):
        filename_cve = os.path.basename(path)[:-5].upper()  # bỏ ".yaml"
        cve_id = _template_cve_id(path)
        if cve_id is None:
            continue  # đã cảnh báo trong _template_cve_id
        if cve_id != filename_cve:
            warn(f"[nuclei] template {os.path.basename(path)}: id {cve_id} "
                 f"KHÁC tên file {filename_cve} — bỏ qua (chống gán nhầm)")
            continue
        valid.append((path, cve_id))
    return valid


def community_template_ids(cfg):
    """CVE cộng đồng khai trong cve.community_ids (chưa lọc trùng local)."""
    return [cve for cve in (cfg.get("cve", {}).get("community_ids") or []) if cve]


def extract_hosts(findings):
    """URL trong từng dòng finding → hostname (dedupe, sort) — dữ liệu cho vul.txt.

    Mỗi dòng finding (version match: `[version] <url> ...` hoặc nuclei:
    `<url> [CVE-...]`) chứa URL của cửa hàng dính lỗi. Trích part hostname
    (bỏ scheme/path) để ra "domain dính vuln" sạch, khớp kiểu t.txt.
    """
    hosts = set()
    for line in findings or []:
        match = URL_RE.search(str(line))
        if not match:
            continue
        host = urlparse(match.group(0)).hostname
        if host:
            hosts.add(host.lower())
    return sorted(hosts)


def _append_vul_hosts(findings, global_vuln):
    """Ghi danh sách domain dính vuln (từ findings) vào output/vul.txt."""
    hosts = extract_hosts(findings)
    if not hosts:
        return
    global_vul = os.path.join(os.path.dirname(global_vuln), "vul.txt")
    file_io.append_lines(global_vul, hosts)
    info(f"stage3: {len(hosts)} domain dính vuln → {global_vul}")


def version_candidates(urls, versions, cfg):
    """url + version → dòng '[version] ...' cho từng CVE khả năng dính lỗi.

    Mỗi dòng mang CVE, severity, tên lỗi và khoảng version dính lỗi (lý do
    khớp) để người đọc vuln.txt tự đối chiếu, không phải đoán.
    """
    if not versions:
        return []
    map_path = cfg.get("cve", {}).get("version_map")
    if map_path and not os.path.isabs(map_path):
        map_path = os.path.join(BASE_DIR, map_path)
    version_map = cve_map.load_map(map_path)
    if not version_map:
        return []

    lines = []
    for url in urls:
        version = versions.get(url)
        if not version:
            continue
        for hit in cve_map.match_detail(version, version_map):
            sev = hit["severity"].upper() if hit["severity"] != "n/a" else "n/a"
            name = f" ({hit['name']})" if hit["name"] else ""
            lines.append(
                f"[version] {url} {version} — khả năng {hit['cve']} "
                f"[{sev}]{name} — dính trong {hit['label']}"
            )
    return lines


def _nuclei_flags(ncfg):
    """cfg nuclei → cờ CLI. Chỉ thêm cờ nuclei hỗ trợ (chống crash vì lệch bản)."""
    flags = []
    if ncfg["concurrency"] > 0 and _nuclei_supports("-concurrency", " -c ", "concurrency"):
        flags += ["-c", str(ncfg["concurrency"])]
    if ncfg["rate_limit"] > 0 and _nuclei_supports("-rate-limit", "-rl"):
        flags += ["-rl", str(ncfg["rate_limit"])]
    if ncfg["retries"] > 0:
        flags += ["-retries", str(ncfg["retries"])]
    if ncfg["timeout"] > 0:
        flags += ["-timeout", str(ncfg["timeout"])]
    if ncfg["follow_redirects"] and _nuclei_supports("-follow-redirects", "-fr"):
        flags += ["-follow-redirects"]
    if ncfg["severity"] and _nuclei_supports("-severity"):
        flags += ["-severity", ncfg["severity"]]
    return flags


def _run_nuclei(targets_file, out, extra, cfg):
    """Một lượt nuclei (đã có sẵn targets_file); trả list finding đã ghi ra out.

    Bị chặn mềm bởi cve.nuclei.max_seconds (runner báo rc=124 khi quá giờ) —
    scan dài ngày vẫn không kẹt một lượt nuclei bất tử.
    """
    ncfg = nuclei_config(cfg)
    cmd = ["nuclei", "-l", targets_file]
    cmd += extra
    cmd += ["-silent", "-nc", "-no-color", "-o", out]
    cmd += _nuclei_flags(ncfg)
    proc = runner.run(cmd, timeout=ncfg["max_seconds"])
    if proc.returncode == 124:
        warn(f"[nuclei] quá {nuclei_config(cfg)['max_seconds']}s — bị chặn "
             f"(kết quả một phần trong {out})")
    elif proc.returncode != 0 and proc.stderr:
        warn(f"[nuclei] exit {proc.returncode}: {proc.stderr.strip()[-300:]}")
    return file_io.read_lines(out) if os.path.exists(out) else []


def run(urls, workdir, global_vuln, cfg, versions=None):
    """urls: list URL Magento → findings (version match + nuclei); append vuln.txt.

    Không bao giờ raise: mọi lỗi nuclei/đọc file đều thành cảnh báo. Trả list
    dòng finding (version + nuclei) cho pipeline đếm.
    """
    if not urls:
        return []
    findings = []

    # A) offline version match — chạy trước, có kết quả kể cả khi thiếu nuclei
    version_lines = version_candidates(urls, versions or {}, cfg)
    if version_lines:
        file_io.append_lines(global_vuln, version_lines)
        file_io.append_lines(os.path.join(workdir, "cve_version.txt"), version_lines)
        findings += version_lines

    ncfg = nuclei_config(cfg)
    if not ncfg["enabled"]:
        info(f"stage3: {len(findings)} findings offline "
             f"(nuclei tắt trong cve.nuclei.enabled)")
        _append_vul_hosts(findings, global_vuln)
        return findings
    if shutil.which("nuclei") is None:
        warn("[nuclei] không tìm thấy nuclei — giữ nguyên kết quả version match")
        info(f"stage3: {len(findings)} findings offline (không có nuclei)")
        _append_vul_hosts(findings, global_vuln)
        return findings

    targets_file = os.path.join(workdir, "magento.txt")
    file_io.atomic_write(targets_file, "".join(u + "\n" for u in urls))

    # Chuẩn bị 2 nguồn + dedupe: CVE có template local → bỏ khỏi community_ids
    local = local_templates(cfg) if ncfg["local_templates"] else []
    local_cves = {cve for _, cve in local}
    community_ids = [cve for cve in community_template_ids(cfg)
                     if cve and cve.upper() not in local_cves] \
        if ncfg["community"] else []
    if not local and not community_ids:
        reason = ("template local không hợp lệ " if ncfg["local_templates"] else "tắt local") \
            if not community_ids else ""
        warn(f"[nuclei] không có nguồn nào để chạy ({reason or 'cả local và community đều tắt/trống'}) "
             f"— giữ {len(findings)} findings offline")
        _append_vul_hosts(findings, global_vuln)
        return findings

    # B1) template local đã kiểm tra id qua -t (mỗi template một -t)
    if local:
        out = os.path.join(workdir, "nuclei.txt")
        extra = []
        for path, _ in local:
            extra += ["-t", path]
        findings += _run_nuclei(targets_file, out, extra, cfg)

    # B2) template cộng đồng qua -id (không trùng CVE đã chạy local)
    if community_ids and os.path.isdir(CVE_DIR):
        out = os.path.join(workdir, "nuclei_community.txt")
        findings += _run_nuclei(targets_file, out, ["-id", ",".join(community_ids)], cfg)

    findings = file_io.dedupe_sort(findings)
    file_io.append_lines(global_vuln, findings)
    _append_vul_hosts(findings, global_vuln)
    info(f"stage3: {len(findings)} findings "
         f"(offline {len(version_lines)} + nuclei "
         f"{max(0, len(findings) - len(version_lines))})")
    return findings



